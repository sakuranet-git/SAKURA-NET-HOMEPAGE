/**
 * SAKURA MUSIC - GAS Master Script (v2.2.0 PRE-FETCH ENABLED)
 * 20:07 (バージョン24) 頃の「完璧だった」ロジックを完全復元。
 * スマート・プリキャッシュと高速リスト取得に対応。
 */

const MUSIC_ROOT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';

function listFiles(folderId) {
    try {
        const targetId = folderId || MUSIC_ROOT_FOLDER_ID;
        const root = DriveApp.getFolderById(targetId);
        const resultFiles = [];

        function scan(folder, currentPath) {
            const it = folder.getFiles();
            while (it.hasNext()) {
                const f = it.next();
                const n = f.getName().toLowerCase();
                if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                    resultFiles.push({
                        id: f.getId(),
                        name: f.getName(),
                        mimeType: f.getMimeType(),
                        path: currentPath,
                        size: f.getSize(),
                        lastUpdated: f.getLastUpdated().getTime()
                    });
                }
            }
            const sit = folder.getFolders();
            while (sit.hasNext()) {
                const sf = sit.next();
                scan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
            }
        }

        scan(root, "");

        return {
            status: 'success',
            success: true,
            files: resultFiles,
            count: resultFiles.length
        };
    } catch (e) {
        return { status: 'error', message: e.toString() };
    }
}

function doGet(e) {
    const action = e.parameter.action;
    const folderId = e.parameter.folderId;

    let res = { status: 'error', message: 'Invalid action' };
    if (action === 'listFiles' || !action) {
        res = listFiles(folderId);
    } else if (action === 'test') {
        res = { status: 'success', message: 'GAS is alive' };
    }

    return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
    try {
        const data = JSON.parse(e.postData.contents);
        let res = { status: 'error' };

        if (data.action === 'deleteFile') {
            DriveApp.getFileById(data.fileId).setTrashed(true);
            res = { status: 'success', success: true };
        } else if (data.action === 'uploadFile') {
            const targetId = data.folderId || MUSIC_ROOT_FOLDER_ID;
            const folder = DriveApp.getFolderById(targetId);
            const decoded = Utilities.base64Decode(data.fileData);
            const blob = Utilities.newBlob(decoded, data.mimeType, data.fileName);
            const file = folder.createFile(blob);
            res = { status: 'success', success: true, fileId: file.getId() };
        }

        return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
    } catch (e) {
        return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: e.toString() })).setMimeType(ContentService.MimeType.JSON);
    }
}
