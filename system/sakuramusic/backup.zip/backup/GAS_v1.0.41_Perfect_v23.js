/**
 * SAKURA MUSIC - GAS Script (v1.0.59 - Version 23 RESTORATION)
 * Base64 エンコード方式による確実なストリーミングを物理復元。
 */

const MUSIC_ROOT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';

function doGet(e) { return handleRequest(e); }
function doPost(e) { return handleRequest(e); }

function handleRequest(e) {
    try {
        var p = (e.postData && e.postData.contents) ? JSON.parse(e.postData.contents) : e.parameter;

        // ストリーム取得 (Base64) - これが 19:38 版の心臓部
        if (p.action === 'getStream') {
            var file = DriveApp.getFileById(p.fileId);
            var blob = file.getBlob();
            return createResponse({
                success: true,
                data: Utilities.base64Encode(blob.getBytes()),
                mimeType: file.getMimeType()
            });
        }

        // ファイル一覧
        if (p.action === 'listFiles' || !p.action) {
            var root = DriveApp.getFolderById(MUSIC_ROOT_FOLDER_ID);
            var files = [];
            var it = root.getFiles();
            while (it.hasNext()) {
                var f = it.next();
                var n = f.getName().toLowerCase();
                if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                    files.push({ id: f.getId(), name: f.getName() });
                }
            }
            return createResponse({ success: true, files: files });
        }

        // アップロード
        if (p.action === 'uploadFile') {
            var folder = DriveApp.getFolderById(MUSIC_ROOT_FOLDER_ID);
            var data = p.fileData.indexOf(',') > -1 ? p.fileData.split(',')[1] : p.fileData;
            var file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(data), p.mimeType, p.fileName));
            return createResponse({ success: true, fileId: file.getId() });
        }

        // 削除
        if (p.action === 'deleteFile') {
            DriveApp.getFileById(p.fileId).setTrashed(true);
            return createResponse({ success: true });
        }

        return createResponse({ success: false, message: 'Unknown action' });
    } catch (err) {
        return createResponse({ success: false, message: err.toString() });
    }
}

function createResponse(data) {
    return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
