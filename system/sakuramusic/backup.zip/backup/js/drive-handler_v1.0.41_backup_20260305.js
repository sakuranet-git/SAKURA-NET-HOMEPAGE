/**
 * SAKURA MUSIC - Google Drive Handler
 * GAS (Google Apps Script) プロキシ経由で Google Drive の音楽ファイルを管理
 */

const DriveHandler = {
    // ai.sakuranet@gmail.com 向けの高速版 GAS プロキシ URL
    // ai.sakuranet@gmail.com 向けの最新・高速版 GAS プロキシ URL
    gasUrl: 'https://script.google.com/macros/s/AKfycbyRhhQtzAaBwXNiCPrFR1Tg3yh1aRw0YWCYXjbD-kibNpff4RqUhyv0mCc1t9ISFJNS/exec',

    // 音楽用フォルダの設定
    folderName: 'SAKURA_MUSIC',
    rootFolderId: '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS',

    // キャッシュ設定 (5分間)
    _cache: null,
    _cacheTimestamp: 0,
    _cacheDuration: 5 * 60 * 1000,

    /**
     * Drive 内の音楽ファイル一覧を取得
     */
    async listFiles(forceRefresh = false) {
        // キャッシュチェック
        const now = Date.now();
        if (!forceRefresh && this._cache && (now - this._cacheTimestamp < this._cacheDuration)) {
            console.log('Using Drive file list from cache');
            return this._cache;
        }

        try {
            const url = new URL(this.gasUrl);
            url.searchParams.append('action', 'listFiles');
            url.searchParams.append('customerName', this.folderName);
            url.searchParams.append('folderId', this.rootFolderId);
            url.searchParams.append('recursive', 'true');

            const res = await fetch(url.toString(), { redirect: 'follow' });
            if (!res.ok) throw new Error('Network response was not ok');

            const result = await res.json();
            if (result.status === 'success' || result.success) {
                const files = result.files || [];
                const filtered = files.filter(f => {
                    const low = f.name.toLowerCase();
                    return low.endsWith('.mp3') || low.endsWith('.m4a') || low.endsWith('.wav') || low.endsWith('.flac');
                });

                // キャッシュに保存 (0件の場合はキャッシュせず、次回再取得を試みる)
                if (filtered.length > 0) {
                    this._cache = filtered;
                    this._cacheTimestamp = now;
                } else {
                    this._cache = null;
                }
                return filtered;
            } else {
                console.error('Drive list error:', result.message);
                return [];
            }
        } catch (err) {
            console.error('DriveHandler.listFiles failed:', err);
            return [];
        }
    },

    /**
     * ファイルを Drive へアップロード
     */
    async uploadFile(file, onProgress) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = async (e) => {
                const base64Data = e.target.result.split(',')[1];
                const payload = JSON.stringify({
                    action: 'uploadFile',
                    customerName: this.folderName,
                    folderId: this.rootFolderId,
                    fileName: file.name,
                    mimeType: file.type || 'application/octet-stream',
                    fileData: base64Data
                });

                try {
                    const res = await fetch(this.gasUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'text/plain' },
                        body: payload,
                        redirect: 'follow'
                    });
                    const result = await res.json();
                    // キャッシュをクリア
                    DriveHandler._cache = null;
                    // フロントエンドのために success プロパティを保証する
                    const normalizedResult = {
                        success: result.status === 'success' || result.success === true,
                        message: result.message,
                        fileId: result.fileId
                    };
                    resolve(normalizedResult);
                } catch (err) {
                    reject(err);
                }
            };
            reader.onerror = (err) => reject(err);
            reader.readAsDataURL(file);
        });
    },

    /**
     * ファイルを削除
     */
    async deleteFile(fileId) {
        try {
            const payload = JSON.stringify({
                action: 'deleteFile',
                fileId: fileId
            });

            const res = await fetch(this.gasUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain' },
                body: payload,
                redirect: 'follow'
            });
            const result = await res.json();
            // キャッシュをクリア
            this._cache = null;
            return {
                success: result.status === 'success' || result.success === true,
                message: result.message
            };
        } catch (err) {
            console.error('DriveHandler.deleteFile failed:', err);
            return { success: false, message: err.message };
        }
    }
};
