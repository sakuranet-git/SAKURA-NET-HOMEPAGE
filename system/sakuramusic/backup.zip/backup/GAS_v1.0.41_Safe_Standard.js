/**
 * SAKURA MUSIC - GAS Master Script (v2.9.0 SAFE STANDARD)
 * - 「無効な引数: q」エラーを物理的に回避するシンプル設計
 * - searchFiles 等のクエリ系メソッドを一切使用せず、Direct ID & Name 取得のみを使用
 */

const TARGET_FOLDER_NAME = 'SAKURA_MUSIC';
const FALLBACK_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';

function doGet(e) { return handleRequest(e); }
function doPost(e) { return handleRequest(e); }

function handleRequest(e) {
    try {
        const p = (e.postData && e.postData.contents) ? JSON.parse(e.postData.contents) : e.parameter;
        const action = p.action || 'listFiles';

        // フォルダ取得：searchは使わずに getFoldersByName のみ使用
        function getFolder(id) {
            if (id && id.length > 20) {
                // IDがURLなら抽出
                const match = id.match(/[-\w]{25,}/);
                const cleanId = match ? match[0] : id;
                try { return DriveApp.getFolderById(cleanId); } catch (err) { }
            }
            const folders = DriveApp.getFoldersByName(TARGET_FOLDER_NAME);
            if (folders.hasNext()) return folders.next();
            try { return DriveApp.getFolderById(FALLBACK_ID); } catch (err) { }
            return null;
        }

        const folder = getFolder(p.folderId || p.driveFolderId);
        if (!folder) return createResponse({ success: false, message: 'Drive内に SAKURA_MUSIC フォルダが見てかりません。' });

        if (action === 'listFiles') {
            const files = [];
            function recursiveScan(fld, currentPath) {
                const fileIt = fld.getFiles();
                while (fileIt.hasNext()) {
                    const f = fileIt.next();
                    const n = f.getName().toLowerCase();
                    if (/\.(mp3|m4a|wav|flac|ogg|aac)$/.test(n)) {
                        files.push({ id: f.getId(), name: f.getName(), path: currentPath, mimeType: f.getMimeType() });
                    }
                }
                const foldIt = fld.getFolders();
                while (foldIt.hasNext()) {
                    const sf = foldIt.next();
                    recursiveScan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
                }
            }
            recursiveScan(folder, "");
            return createResponse({ success: true, files: files, count: files.length });
        }

        if (action === 'getStream') {
            const file = DriveApp.getFileById(p.fileId);
            return createResponse({ success: true, data: Utilities.base64Encode(file.getBlob().getBytes()), mimeType: file.getMimeType() });
        }

        if (action === 'uploadFile') {
            const data = p.fileData.indexOf(',') > -1 ? p.fileData.split(',')[1] : p.fileData;
            const file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(data), p.mimeType, p.fileName));
            return createResponse({ success: true, fileId: file.getId() });
        }

        if (action === 'deleteFile') {
            DriveApp.getFileById(p.fileId).setTrashed(true);
            return createResponse({ success: true });
        }

        return createResponse({ success: false, message: 'Unknown action' });
    } catch (err) {
        return createResponse({ success: false, message: '一覧取得失敗: ' + err.toString() });
    }
}

function createResponse(data) {
    return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
