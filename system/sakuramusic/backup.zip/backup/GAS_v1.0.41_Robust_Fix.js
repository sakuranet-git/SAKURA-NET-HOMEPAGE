/**
 * SAKURA MUSIC - GAS Master Script (v2.6.0 ROBUST SYNC)
 * - フォルダIDが機能しない場合、名前（SAKURA_MUSIC）で自動検索する機能を追加
 * - 検索結果の詳細（パス、サイズ等）をログとして返却
 * - Base64 方式の安定性を維持
 */

const DEFAULT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';
const FOLDER_NAME = 'SAKURA_MUSIC';

function doGet(e) { return handleRequest(e); }
function doPost(e) { return handleRequest(e); }

function handleRequest(e) {
    try {
        const p = (e.postData && e.postData.contents) ? JSON.parse(e.postData.contents) : e.parameter;
        const action = p.action || 'listFiles';

        // フォルダの取得ロジック（ID優先、失敗したら名前で検索）
        function getTargetFolder(id) {
            if (id && id !== DEFAULT_FOLDER_ID) {
                try { return DriveApp.getFolderById(id); } catch (err) { }
            }
            const folders = DriveApp.getFoldersByName(FOLDER_NAME);
            if (folders.hasNext()) return folders.next();

            // それでもなければ、IDがデフォルトならそれを使う
            try { return DriveApp.getFolderById(DEFAULT_FOLDER_ID); } catch (err) { }
            return null;
        }

        const folder = getTargetFolder(p.folderId || p.driveFolderId);
        if (!folder && action !== 'test') {
            return createResponse({ success: false, message: 'フォルダが見つかりません。Google Drive内に SAKURA_MUSIC フォルダを作成してください。' });
        }

        // 1. ストリーム取得 (Base64)
        if (action === 'getStream') {
            const file = DriveApp.getFileById(p.fileId);
            return createResponse({
                success: true,
                data: Utilities.base64Encode(file.getBlob().getBytes()),
                mimeType: file.getMimeType()
            });
        }

        // 2. ファイル一覧 (再帰検索)
        if (action === 'listFiles') {
            const resultFiles = [];
            function scan(fld, currentPath) {
                const it = fld.getFiles();
                while (it.hasNext()) {
                    const f = it.next();
                    const n = f.getName().toLowerCase();
                    if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                        resultFiles.push({
                            id: f.getId(),
                            name: f.getName(),
                            mimeType: f.getMimeType(),
                            path: currentPath,
                            size: f.getSize()
                        });
                    }
                }
                const sit = fld.getFolders();
                while (sit.hasNext()) {
                    const sf = sit.next();
                    scan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
                }
            }

            scan(folder, "");
            return createResponse({
                success: true,
                files: resultFiles,
                folderName: folder.getName(),
                folderId: folder.getId(),
                count: resultFiles.length
            });
        }

        // 3. アップロード
        if (action === 'uploadFile') {
            const data = p.fileData.indexOf(',') > -1 ? p.fileData.split(',')[1] : p.fileData;
            const file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(data), p.mimeType, p.fileName));
            return createResponse({ success: true, fileId: file.getId() });
        }

        // 4. 削除
        if (action === 'deleteFile') {
            DriveApp.getFileById(p.fileId).setTrashed(true);
            return createResponse({ success: true });
        }

        if (action === 'test') return createResponse({ success: true, message: 'GAS is ready' });

        return createResponse({ success: false, message: 'Unknown action: ' + action });
    } catch (err) {
        return createResponse({ success: false, message: err.toString() });
    }
}

function createResponse(data) {
    return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
