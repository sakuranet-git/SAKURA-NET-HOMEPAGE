/**
 * SAKURA MUSIC - GAS Master Script (v2.0.0 DEFINITIVE RESTORATION)
 * 修復された JS 連携（v1.0.41ベース）と完全に同期。
 */

const MUSIC_ROOT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';

function listFiles(folderId) {
    try {
        const targetId = folderId || MUSIC_ROOT_FOLDER_ID;
        const root = DriveApp.getFolderById(targetId);
        const resultFiles = [];

        // 全ての階層から音楽ファイルを探す（再帰的）
        function scan(folder, currentPath) {
            // ファイルの取得
            const it = folder.getFiles();
            while (it.hasNext()) {
                const f = it.next();
                const n = f.getName().toLowerCase();
                if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                    resultFiles.push({
                        id: f.getId(),
                        name: f.getName(),
                        mimeType: f.getMimeType(),
                        path: currentPath // フォルダ階層情報を含める
                    });
                }
            }

            // サブフォルダの取得
            const sit = folder.getFolders();
            while (sit.hasNext()) {
                const sf = sit.next();
                scan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
            }
        }

        scan(root, "");

        // JS 側が期待する 'status: success' 形式で返却
        return {
            status: 'success',
            success: true,
            files: resultFiles,
            count: resultFiles.length
        };
    } catch (e) {
        return { status: 'error', message: e.toString() };
    }
}

function deleteFile(id) {
    try {
        DriveApp.getFileById(id).setTrashed(true);
        return { status: 'success', success: true };
    } catch (e) {
        return { status: 'error', message: e.toString() };
    }
}

function doGet(e) {
    const action = e.parameter.action;
    const folderId = e.parameter.folderId;

    let res = { status: 'error', message: 'Invalid action' };

    if (action === 'listFiles' || !action) {
        res = listFiles(folderId);
    }

    return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
    try {
        // アップロード等の POST リクエスト処理
        const data = JSON.parse(e.postData.contents);
        let res = { status: 'error' };

        if (data.action === 'deleteFile') {
            res = deleteFile(data.fileId);
        }

        return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
    } catch (e) {
        return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: e.toString() })).setMimeType(ContentService.MimeType.JSON);
    }
}
