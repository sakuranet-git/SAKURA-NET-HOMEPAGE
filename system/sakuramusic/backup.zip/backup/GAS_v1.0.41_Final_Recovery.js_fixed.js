/**
 * SAKURA MUSIC - GAS Script (v2.1.1 FOR V1.0.41 PERFECT RECOVERY)
 * v1.0.41 の JS が要求する全てのパラメータに対応し、名前を統一。
 */

const DEFAULT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';

function listFiles(folderId) {
    try {
        const targetId = folderId || DEFAULT_FOLDER_ID;
        const root = DriveApp.getFolderById(targetId);
        const resultFiles = [];

        // 全階層スキャン
        function scan(folder, currentPath) {
            const it = folder.getFiles();
            while (it.hasNext()) {
                const f = it.next();
                const n = f.getName().toLowerCase();
                if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                    resultFiles.push({
                        id: f.getId(),
                        name: f.getName(),
                        mimeType: f.getMimeType(),
                        path: currentPath
                    });
                }
            }
            const sit = folder.getFolders();
            while (sit.hasNext()) {
                const sf = sit.next();
                scan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
            }
        }

        scan(root, "");

        return {
            status: 'success',
            files: resultFiles
        };
    } catch (e) {
        return { status: 'error', message: e.toString() };
    }
}

function doGet(e) {
    const action = e.parameter.action;
    // v1.0.41 JS は 'customerName' で送るため、それに合わせる
    const folderId = e.parameter.folderId;

    let res = { status: 'error', message: 'Invalid action' };
    if (action === 'listFiles' || !action) {
        res = listFiles(folderId);
    } else if (action === 'test') {
        res = { status: 'success', message: 'GAS is alive' };
    }

    return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
    try {
        const data = JSON.parse(e.postData.contents);
        let res = { status: 'error' };
        if (data.action === 'deleteFile') {
            DriveApp.getFileById(data.fileId).setTrashed(true);
            res = { status: 'success' };
        } else if (data.action === 'uploadFile') {
            const targetId = data.folderId || DEFAULT_FOLDER_ID;
            const folder = DriveApp.getFolderById(targetId);
            const decoded = Utilities.base64Decode(data.fileData);
            const blob = Utilities.newBlob(decoded, data.mimeType, data.fileName);
            const file = folder.createFile(blob);
            res = { status: 'success', fileId: file.getId() };
        }
        return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
    } catch (e) {
        return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: e.toString() })).setMimeType(ContentService.MimeType.JSON);
    }
}
