/**
 * SAKURA MUSIC - GAS Script (v2.1.0 FOR V1.0.41 PERFECT RECOVERY)
 * v1.0.41 の JS が要求する全てのパラメータ（googleAccount, folderId）に対応。
 */

const DEFAULT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';

function listFiles(account, folderId) {
    try {
        const targetId = folderId || DEFAULT_FOLDER_ID;
        const root = DriveApp.getFolderById(targetId);
        const resultFiles = [];

        // 全階層スキャン
        function scan(folder, currentPath) {
            const it = folder.getFiles();
            while (it.hasNext()) {
                const f = it.next();
                const n = f.getName().toLowerCase();
                if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                    resultFiles.push({
                        id: f.getId(),
                        name: f.getName(),
                        mimeType: f.getMimeType(),
                        path: currentPath
                    });
                }
            }
            const sit = folder.getFolders();
            while (sit.hasNext()) {
                const sf = sit.next();
                scan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
            }
        }

        scan(root, "");

        // v1.0.41 は 'status: success' を期待しているため、それに合わせる
        return {
            status: 'success',
            files: resultFiles
        };
    } catch (e) {
        return { status: 'error', message: e.toString() };
    }
}

function doGet(e) {
    const action = e.parameter.action;
    const account = e.parameter.googleAccount; // 重要: v1.0.41 の JS はこれを送る
    const folderId = e.parameter.folderId;

    let res = { status: 'error', message: 'Invalid action' };
    if (action === 'listFiles' || !action) {
        res = listFiles(account, folderId);
    } else if (action === 'test') {
        res = { status: 'success', message: 'GAS is alive' };
    }

    return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
    try {
        const data = JSON.parse(e.postData.contents);
        let res = { status: 'error' };
        if (data.action === 'deleteFile') {
            DriveApp.getFileById(data.fileId).setTrashed(true);
            res = { status: 'success' };
        }
        return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
    } catch (e) {
        return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: e.toString() })).setMimeType(ContentService.MimeType.JSON);
    }
}
