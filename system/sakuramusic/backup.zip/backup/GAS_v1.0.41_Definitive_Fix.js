/**
 * SAKURA MUSIC - GAS Master Script (v2.5.0 DEFINITIVE FIX)
 * 全ての不整合を解消した究極の修正版。
 * - 再帰検索 (Deep Search) 対応
 * - Base64 安定ストリーミング方式
 * - マルチパラメータ (folderId, customerName) 対応
 */

const DEFAULT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';

function doGet(e) { return handleRequest(e); }
function doPost(e) { return handleRequest(e); }

function handleRequest(e) {
    try {
        const p = (e.postData && e.postData.contents) ? JSON.parse(e.postData.contents) : e.parameter;
        const action = p.action || 'listFiles';

        // 1. ストリーム取得 (Base64)
        if (action === 'getStream') {
            const file = DriveApp.getFileById(p.fileId);
            return createResponse({
                success: true,
                status: 'success',
                data: Utilities.base64Encode(file.getBlob().getBytes()),
                mimeType: file.getMimeType()
            });
        }

        // 2. ファイル一覧 (再帰検索)
        if (action === 'listFiles') {
            const targetId = p.folderId || p.driveFolderId || DEFAULT_FOLDER_ID;
            const root = DriveApp.getFolderById(targetId);
            const resultFiles = [];

            function scan(folder, currentPath) {
                const it = folder.getFiles();
                while (it.hasNext()) {
                    const f = it.next();
                    const n = f.getName().toLowerCase();
                    if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                        resultFiles.push({
                            id: f.getId(),
                            name: f.getName(),
                            mimeType: f.getMimeType(),
                            path: currentPath
                        });
                    }
                }
                const sit = folder.getFolders();
                while (sit.hasNext()) {
                    const sf = sit.next();
                    scan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
                }
            }

            scan(root, "");
            return createResponse({
                success: true,
                status: 'success',
                files: resultFiles,
                count: resultFiles.length
            });
        }

        // 3. アップロード
        if (action === 'uploadFile') {
            const targetId = p.folderId || p.driveFolderId || DEFAULT_FOLDER_ID;
            const folder = DriveApp.getFolderById(targetId);
            const data = p.fileData.indexOf(',') > -1 ? p.fileData.split(',')[1] : p.fileData;
            const file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(data), p.mimeType, p.fileName));
            return createResponse({ success: true, status: 'success', fileId: file.getId() });
        }

        // 4. 削除
        if (action === 'deleteFile') {
            DriveApp.getFileById(p.fileId).setTrashed(true);
            return createResponse({ success: true, status: 'success' });
        }

        return createResponse({ success: false, status: 'error', message: 'Unknown action: ' + action });
    } catch (err) {
        return createResponse({ success: false, status: 'error', message: err.toString() });
    }
}

function createResponse(data) {
    return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
