/**
 * SAKURA MUSIC - GAS Master Script (v2.8.0 ULTIMATE STABLE)
 * - GET/POST 両対応（赤ランプ・CORS回避）
 * - フォルダIDの自動クレンジング（URLからIDを抽出）
 * - 再帰検索 (Recursive Scan) の徹底
 */

const DEFAULT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';
const TARGET_FOLDER_NAME = 'SAKURA_MUSIC';

function doGet(e) { return handleRequest(e); }
function doPost(e) { return handleRequest(e); }

function handleRequest(e) {
    try {
        const p = (e.postData && e.postData.contents) ? JSON.parse(e.postData.contents) : e.parameter;
        const action = p.action || 'listFiles';

        // フォルダIDを抽出・クレンジングする関数
        function cleanId(id) {
            if (!id) return null;
            // URL形式で入力された場合にID部分だけを抜き出す
            const match = id.match(/[-\w]{25,}/);
            return match ? match[0] : id;
        }

        // フォルダ取得の究極ロジック
        function findFolder(id) {
            const targetId = cleanId(id);
            if (targetId && targetId !== DEFAULT_FOLDER_ID) {
                try { return DriveApp.getFolderById(targetId); } catch (err) { }
            }
            // 名前で検索
            const folders = DriveApp.getFoldersByName(TARGET_FOLDER_NAME);
            if (folders.hasNext()) return folders.next();

            // デフォルトID
            try { return DriveApp.getFolderById(DEFAULT_FOLDER_ID); } catch (err) { }
            return null;
        }

        const folder = findFolder(p.folderId || p.driveFolderId);

        if (action === 'test') return createResponse({ success: true, message: 'GAS Connection OK' });
        if (!folder) return createResponse({ success: false, message: 'Google Drive内に SAKURA_MUSIC フォルダが見つかりません。' });

        // 1. ファイル一覧
        if (action === 'listFiles') {
            const files = [];
            function scan(fld, path) {
                const it = fld.getFiles();
                while (it.hasNext()) {
                    const f = it.next();
                    const n = f.getName().toLowerCase();
                    // 対応フォーマット
                    if (/\.(mp3|m4a|wav|flac|ogg|aac)$/.test(n)) {
                        files.push({
                            id: f.getId(),
                            name: f.getName(),
                            path: path,
                            mimeType: f.getMimeType()
                        });
                    }
                }
                const sit = fld.getFolders();
                while (sit.hasNext()) {
                    const sf = sit.next();
                    scan(sf, path ? path + '/' + sf.getName() : sf.getName());
                }
            }
            scan(folder, "");
            return createResponse({
                success: true,
                files: files,
                folderName: folder.getName(),
                count: files.length
            });
        }

        // 2. ストリーム (Base64)
        if (action === 'getStream') {
            const file = DriveApp.getFileById(p.fileId);
            return createResponse({
                success: true,
                data: Utilities.base64Encode(file.getBlob().getBytes()),
                mimeType: file.getMimeType()
            });
        }

        // 3. アップロード
        if (action === 'uploadFile') {
            const data = p.fileData.indexOf(',') > -1 ? p.fileData.split(',')[1] : p.fileData;
            const file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(data), p.mimeType, p.fileName));
            return createResponse({ success: true, fileId: file.getId() });
        }

        // 4. 削除
        if (action === 'deleteFile') {
            DriveApp.getFileById(p.fileId).setTrashed(true);
            return createResponse({ success: true });
        }

        return createResponse({ success: false, message: 'Unknown action: ' + action });
    } catch (err) {
        return createResponse({ success: false, message: err.toString() });
    }
}

function createResponse(data) {
    return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
