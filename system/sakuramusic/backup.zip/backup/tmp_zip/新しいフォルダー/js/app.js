/* 
 * SAKURA MUSIC - App Main
 * v1.0.25 - Library Search & Local Music Integration
 */

// API 設定の管理
const AppConfig = {
    appleToken: localStorage.getItem('sakura_apple_token') || '',
    googleClientId: localStorage.getItem('sakura_google_id') || '1034545304058-8414nlkdpms40gjknm47r9v3efbbjdas.apps.googleusercontent.com',
    googleAccount: 'lilly.sakura07@gmail.com', // ユーザー提供
    googleApiKey: localStorage.getItem('sakura_google_api_key') || 'AIzaSyD-IoqRej9KOCWDYy8W7InW3qpu6xxbW8Y',
    gasUrl: localStorage.getItem('sakura_gas_url') || 'https://script.google.com/macros/s/AKfycbyRhhQtzAaBwXNiCPrFR1Tg3yh1aRw0YWCYXjbD-kibNpff4RqUhyv0mCc1t9ISFJNS/exec',
    driveFolderId: localStorage.getItem('sakura_drive_folder_id') || '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS',

    save(apple, google, googleApi, gasUrl, folderId) {
        this.appleToken = apple;
        this.googleClientId = google;
        this.googleApiKey = googleApi || 'AIzaSyD-IoqRej9KOCWDYy8W7InW3qpu6xxbW8Y';
        if (gasUrl) this.gasUrl = gasUrl;
        if (folderId) this.driveFolderId = folderId;

        localStorage.setItem('sakura_apple_token', apple);
        localStorage.setItem('sakura_google_id', google);
        if (googleApi) localStorage.setItem('sakura_google_api_key', googleApi);
        if (gasUrl) localStorage.setItem('sakura_gas_url', gasUrl);
        if (folderId) localStorage.setItem('sakura_drive_folder_id', folderId);
    }
};

document.addEventListener('DOMContentLoaded', () => {
    console.log('SAKURA MUSIC v1.0.25 - Booting');

    // UI 初期化
    initNavigation();
    initSettings();
    initPlayerUI();
    initSearch();

    // YouTube ハンドラー初期化
    YouTubeHandler.init();

    // Apple Music 初期化 (トークンがあれば)
    if (AppConfig.appleToken) {
        AppleMusicHandler.init(AppConfig.appleToken);
    }
});

/**
 * ナビゲーションの初期化
 */
function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            const text = link.innerText.trim();
            if (text.includes('ホーム')) {
                showHome();
            } else if (text.includes('YouTube Music')) {
                showYouTubeLibrary();
            } else if (text.includes('Google Drive')) {
                showDriveLibrary();
            }
        });
    });
}

/**
 * 設定画面の初期化
 */
function initSettings() {
    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settings-modal');
    const saveSettings = document.getElementById('save-settings');

    if (settingsBtn) {
        settingsBtn.addEventListener('click', () => {
            document.getElementById('apple-token-input').value = AppConfig.appleToken;
            document.getElementById('google-id-input').value = AppConfig.googleClientId;
            document.getElementById('google-api-key-input').value = localStorage.getItem('sakura_google_api_key') || '';
            document.getElementById('gas-url-input').value = AppConfig.gasUrl;
            document.getElementById('drive-folder-id-input').value = AppConfig.driveFolderId;
            settingsModal.classList.add('open');
        });
    }

    if (saveSettings) {
        saveSettings.addEventListener('click', () => {
            const apple = document.getElementById('apple-token-input').value;
            const google = document.getElementById('google-id-input').value;
            const googleApi = document.getElementById('google-api-key-input').value;
            const gasUrl = document.getElementById('gas-url-input').value;
            const folderId = document.getElementById('drive-folder-id-input').value;
            AppConfig.save(apple, google, googleApi, gasUrl, folderId);
            settingsModal.classList.remove('open');
            location.reload();
        });
    }

    window.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            settingsModal.classList.remove('open');
        }
    });
}

/**
 * 検索機能の初期化
 */
function initSearch() {
    const searchInputs = [
        document.getElementById('global-search'),
        document.getElementById('center-search')
    ];

    searchInputs.forEach(input => {
        if (!input) return;
        input.addEventListener('keypress', async (e) => {
            if (e.key === 'Enter') {
                const query = input.value.trim();
                if (!query) return;

                console.log('SAKURA Search Start:', query);

                // 全てのビューを非表示
                hideAllViews();

                const searchView = document.getElementById('search-view');
                const searchResults = document.getElementById('search-results');

                searchView.style.display = 'block';
                searchResults.innerHTML = '<p style="text-align: center; opacity: 0.5; grid-column: 1/-1; padding: 40px;">検索中...</p>';

                try {
                    // カタログ & ライブラリ検索
                    const [catalog, library] = await Promise.all([
                        YouTubeHandler.search(query, AppConfig.googleApiKey),
                        searchInLibrary(query)
                    ]);

                    renderCombinedSearchResults(catalog, library);
                } catch (err) {
                    console.error('Search failed:', err);
                    searchResults.innerHTML = `<p style="text-align: center; color: var(--primary); grid-column: 1/-1; padding: 40px;">検索エラーが発生しました。<br><span style="font-size:12px; opacity:0.5;">${err.message}</span></p>`;
                }

                searchInputs.forEach(i => i.value = query);
            }
        });
    });
}

function hideAllViews() {
    document.getElementById('welcome-view').style.display = 'none';
    document.getElementById('search-view').style.display = 'none';
    document.getElementById('library-view').style.display = 'none';
    document.getElementById('playlist-detail-view').style.display = 'none';
    document.getElementById('drive-view').style.display = 'none';
}

function showHome() {
    hideAllViews();
    document.getElementById('welcome-view').style.display = 'block';
}

async function showYouTubeLibrary() {
    hideAllViews();
    const libraryView = document.getElementById('library-view');
    libraryView.style.display = 'block';

    const token = localStorage.getItem('yt_access_token');
    const libraryContent = document.getElementById('library-content');

    if (!token) {
        libraryContent.innerHTML = `
            <div class="glass-card" style="text-align: center; padding: 50px;">
                <h3>YouTube Music 未ログイン</h3>
                <p style="opacity: 0.6; margin: 20px 0;">ライブラリを表示するには Google アカウントでログインしてください。</p>
                <button onclick="loginYouTube()" class="btn-primary" style="padding: 10px 30px;">ログイン</button>
            </div>
        `;
        return;
    }

    libraryContent.innerHTML = '<p style="text-align: center; opacity: 0.5;">カタログを読み込み中...</p>';
    const playlists = await YouTubeHandler.getLibrary();
    renderLibrary(playlists);
}


/**
 * ライブラリ（YouTube）の描画
 */
function renderLibrary(playlists) {
    const libraryContent = document.getElementById('library-content');
    libraryContent.innerHTML = '';

    playlists.forEach(pl => {
        const card = document.createElement('div');
        card.className = 'result-card';
        const itemCount = pl.isSystem ? 'System' : `${pl.contentDetails.itemCount} 曲`;
        card.innerHTML = `
            <img src="${pl.snippet.thumbnails.medium.url}" class="result-thumb">
            <div class="result-title">${pl.snippet.title}</div>
            <div class="result-artist">${itemCount}</div>
        `;
        card.addEventListener('click', () => showPlaylistDetails(pl.id, pl.snippet.title));
        libraryContent.appendChild(card);
    });
}


/**
 * ライブラリ検索ロジック
 */
async function searchInLibrary(query) {
    const playlists = await YouTubeHandler.getLibrary();
    const lowerQuery = query.toLowerCase();
    return playlists
        .filter(pl => pl.snippet.title.toLowerCase().includes(lowerQuery))
        .map(pl => ({ type: 'playlist', data: pl }));
}

/**
 * 検索結果の統合描画
 */
function renderCombinedSearchResults(catalog, library) {
    const resultsGrid = document.getElementById('search-results');
    resultsGrid.innerHTML = '';

    if (library.length > 0) {
        const header = document.createElement('h3');
        header.style.gridColumn = '1 / -1'; header.style.margin = '20px 0 10px';
        header.style.fontSize = '18px'; header.style.color = 'var(--text-pink)';
        header.innerText = '📚 自分のライブラリ';
        resultsGrid.appendChild(header);

        library.forEach(item => {
            const pl = item.data;
            const card = document.createElement('div');
            card.className = 'result-card';
            card.style.borderColor = 'var(--primary)';
            card.innerHTML = `
                <div style="position:absolute; top:10px; right:10px; font-size:10px; background:var(--primary); padding:2px 6px; border-radius:4px;">In Library</div>
                <img src="${pl.snippet.thumbnails.medium.url}" class="result-thumb">
                <div class="result-title">${pl.snippet.title}</div>
                <div class="result-artist">プレイリスト</div>
            `;
            card.style.position = 'relative';
            card.addEventListener('click', () => showPlaylistDetails(pl.id, pl.snippet.title));
            resultsGrid.appendChild(card);
        });
    }

    if (catalog.length > 0) {
        const header = document.createElement('h3');
        header.style.gridColumn = '1 / -1'; header.style.margin = '20px 0 10px';
        header.style.fontSize = '18px'; header.innerText = '🌍 YouTube Music 全体';
        resultsGrid.appendChild(header);
        renderSearchResults(catalog, true);
    }
}

async function showPlaylistDetails(playlistId, title) {
    hideAllViews();
    const detailView = document.getElementById('playlist-detail-view');
    detailView.style.display = 'block';

    document.getElementById('playlist-title').innerText = title;
    const itemsGrid = document.getElementById('playlist-items');
    itemsGrid.innerHTML = '<p style="text-align: center; opacity: 0.5;">読み込み中...</p>';

    const items = await YouTubeHandler.getPlaylistItems(playlistId);
    itemsGrid.innerHTML = '';
    items.forEach((item, index) => {
        const { videoId } = item.snippet.resourceId;
        const { title: trackTitle, thumbnails } = item.snippet;
        const thumbUrl = thumbnails?.default?.url || 'https://via.placeholder.com/40';
        const trackArtist = item.snippet.videoOwnerChannelTitle || 'Various Artists';

        const row = document.createElement('div');
        row.className = 'playlist-row';
        row.style.display = 'flex'; row.style.alignItems = 'center'; row.style.padding = '10px'; row.style.background = 'rgba(255,255,255,0.05)'; row.style.borderRadius = '10px'; row.style.marginBottom = '10px'; row.style.cursor = 'pointer';
        row.innerHTML = `
            <img src="${thumbUrl}" style="width: 40px; height: 40px; border-radius: 4px; margin-right: 15px; object-fit: cover;">
            <div style="flex: 1;"><div style="font-weight: 600;">${trackTitle}</div><div style="font-size: 12px; opacity: 0.6;">${trackArtist}</div></div>
            <div style="opacity: 0.4;">▶️</div>
        `;
        row.addEventListener('click', () => playTrack(videoId, trackTitle, trackArtist, thumbUrl));
        itemsGrid.appendChild(row);
    });
}

function renderSearchResults(items, append = false) {
    const resultsGrid = document.getElementById('search-results');
    if (!append) resultsGrid.innerHTML = '';

    items.forEach(item => {
        const { videoId } = item.id || {};
        const { title, thumbnails, channelTitle } = item.snippet || {};
        if (!videoId || !title) return;

        const card = document.createElement('div');
        card.className = 'result-card';
        card.innerHTML = `
            <img src="${thumbnails?.medium?.url || 'https://via.placeholder.com/180'}" class="result-thumb">
            <div class="result-title">${title}</div>
            <div class="result-artist">${channelTitle || 'Unknown'}</div>
        `;
        card.addEventListener('click', () => playTrack(videoId, title, channelTitle, thumbnails?.default?.url || 'https://via.placeholder.com/40'));
        resultsGrid.appendChild(card);
    });
}

async function showDriveLibrary() {
    hideAllViews();
    document.getElementById('drive-view').style.display = 'block';

    // ステータスランプ初期表示（読み込み中）
    updateDriveStatusLamp('loading');

    const files = await DriveHandler.listFiles();

    if (files && files.length >= 0) {
        updateDriveStatusLamp('ok');
    } else {
        updateDriveStatusLamp('error');
    }

    renderDriveFiles(files);
    setupDriveUpload();
    setupDriveDragAndDrop();
}

function updateDriveStatusLamp(status) {
    const lamp = document.getElementById('drive-status-lamp');
    if (!lamp) return;

    lamp.classList.remove('lamp-ok', 'lamp-error');

    if (status === 'ok') {
        lamp.classList.add('lamp-ok');
        lamp.title = 'Google Drive 接続済み';
    } else if (status === 'error') {
        lamp.classList.add('lamp-error');
        lamp.title = '接続エラー';
    } else {
        lamp.title = '接続確認中...';
    }
}

function renderDriveFiles(files) {
    const driveContent = document.getElementById('drive-content');
    driveContent.innerHTML = '';

    if (files.length === 0) {
        driveContent.innerHTML = '<p style="text-align: center; opacity: 0.5; padding: 40px;">楽曲がありません。アップロードするかファイルをドロップしてください。</p>';
        return;
    }

    files.forEach(f => {
        const item = document.createElement('div');
        item.className = 'drive-list-item';

        item.innerHTML = `
            <div class="drive-list-thumb" style="display: flex; align-items: center; justify-content: center; background: rgba(230, 0, 126, 0.1);">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#e6007e"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
            </div>
            <div class="drive-list-info">
                <div class="drive-list-title">${f.name}</div>
                <div class="drive-list-meta">Google Drive • 音声ファイル</div>
            </div>
            <div class="drive-list-actions">
                <button class="action-btn delete-drive-btn" title="Driveから削除" style="color: #ff4d4d; font-size: 12px;">✕</button>
                <div style="font-size: 10px; opacity: 0.5; align-self: center;">▶</div>
            </div>
        `;

        // 行全体クリックで再生
        item.addEventListener('click', (e) => {
            if (e.target.closest('.delete-drive-btn')) return;
            playTrack(f.id, f.name, 'Google Drive', 'https://via.placeholder.com/180/e6007e/ffffff?text=Drive', true);
        });

        item.querySelector('.delete-drive-btn').addEventListener('click', async (e) => {
            e.stopPropagation();
            if (confirm(`「${f.name}」を Google Drive から削除しますか？`)) {
                const res = await DriveHandler.deleteFile(f.id);
                if (res.success) {
                    showDriveLibrary();
                } else {
                    alert('削除失敗: ' + res.message);
                }
            }
        });

        driveContent.appendChild(item);
    });
}

function setupDriveUpload() {
    const trigger = document.getElementById('drive-upload-trigger');
    const input = document.getElementById('drive-upload-input');

    if (!trigger || !input || trigger.dataset.init) return;
    trigger.dataset.init = "true";

    trigger.addEventListener('click', () => input.click());

    input.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        if (files.length === 0) return;
        await handleMultipleUploads(files);
        input.value = '';
    });
}


function setupDriveDragAndDrop() {
    const driveView = document.getElementById('drive-view');
    if (!driveView || driveView.dataset.dropInit) return;
    driveView.dataset.dropInit = "true";

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        driveView.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
        }, false);
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        driveView.addEventListener(eventName, () => {
            driveView.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        driveView.addEventListener(eventName, () => {
            driveView.classList.remove('dragover');
        }, false);
    });

    driveView.addEventListener('drop', async (e) => {
        const files = Array.from(e.dataTransfer.files).filter(f => {
            const low = f.name.toLowerCase();
            return low.endsWith('.mp3') || low.endsWith('.m4a') || low.endsWith('.wav') || low.endsWith('.flac');
        });

        if (files.length > 0) {
            await handleMultipleUploads(files);
        }
    }, false);
}

async function handleMultipleUploads(files) {
    const progressContainer = document.getElementById('upload-progress-container');
    const progressBar = document.getElementById('upload-progress-bar');
    const filenameDisplay = document.getElementById('upload-filename');
    const percentageDisplay = document.getElementById('upload-percentage');

    progressContainer.style.display = 'block';

    let successCount = 0;
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const displayIndex = i + 1;
        filenameDisplay.innerText = `[${displayIndex}/${files.length}] ${file.name}`;

        progressBar.style.width = '10%';
        percentageDisplay.innerText = '10%';

        try {
            const result = await DriveHandler.uploadFile(file);
            if (result.success) {
                successCount++;
                progressBar.style.width = '100%';
                percentageDisplay.innerText = '100%';
            } else {
                console.error(`Upload failed for ${file.name}:`, result.message);
            }
        } catch (err) {
            console.error(`Upload error for ${file.name}:`, err);
        }
    }

    if (successCount > 0) {
        filenameDisplay.innerText = `${successCount} 個のファイルをアップロード完了✨`;
        setTimeout(() => {
            progressContainer.style.display = 'none';
            showDriveLibrary();
        }, 1500);
    } else {
        alert('全てのアップロードに失敗しました。');
        progressContainer.style.display = 'none';
    }
}

function playTrack(id, title, artist, thumb, isDrive = false) {
    console.log('Playing:', title, isDrive ? '(Drive)' : '');

    // 既存の音声をすべて停止
    if (window.__localAudio) window.__localAudio.pause();
    YouTubeHandler.pause();

    if (isDrive) {
        // Drive REST API を利用したストリーミング URL
        // ブラウザのクッキー制限を回避するため、公開設定フォルダ内のファイルに対して API Key を使用する
        const apiKey = AppConfig.googleApiKey;
        const streamUrl = `https://www.googleapis.com/drive/v3/files/${id}?alt=media&key=${apiKey}`;

        if (window.__localAudio) {
            window.__localAudio.pause();
            window.__localAudio.src = "";
        }

        window.__localAudio = new Audio();
        window.__localAudio.src = streamUrl;

        window.__localAudio.play().catch(err => {
            console.error('Audio play failed:', err);
            // 403 Forbidden 等が起きた場合のメッセージ
            alert('再生に失敗しました。APIキーの制限、またはGoogleのセキュリティ設定が原因の可能性があります。');
        });
    } else {
        YouTubeHandler.play(id);
    }

    // UI更新
    document.querySelector('.track-details h3').innerText = title;
    document.querySelector('.track-details p').innerText = artist;
    document.querySelector('.album-art').style.backgroundImage = `url(${thumb})`;
    document.querySelector('.album-art').style.backgroundSize = 'cover';
    document.querySelector('.play-btn').innerText = '⏸️';

    fetchLyrics(title, artist);
}

function cleanTitle(title) {
    return title.replace(/\[.*?\]/g, '').replace(/\(.*?\)/g, '').replace(/Official Video|Music Video|Lyric Video|Full Audio|MV/gi, '').trim();
}

async function fetchLyrics(title, artist) {
    const lyricsContent = document.getElementById('lyrics-content');
    const headerTitle = document.getElementById('lyrics-track-title');
    const headerArtist = document.getElementById('lyrics-track-artist');

    if (headerTitle) headerTitle.innerText = title;
    if (headerArtist) headerArtist.innerText = artist;
    if (lyricsContent) lyricsContent.innerHTML = '<p style="opacity: 0.3;">歌詞を探しています...</p>';

    const cT = cleanTitle(title);
    const cA = artist.replace(/ - Topic$/i, '').trim();

    try {
        const res = await fetch(`https://lrclib.net/api/get?artist_name=${encodeURIComponent(cA)}&track_name=${encodeURIComponent(cT)}`);
        if (!res.ok) throw new Error();
        const data = await res.json();
        lyricsContent.innerText = data.plainLyrics || data.syncedLyrics.replace(/\[\d+:\d+\.\d+\]/g, '') || '歌詞がありません';
    } catch {
        lyricsContent.innerHTML = `<p style="opacity: 0.5;">歌詞が見つかりませんでした。(${cA} - ${cT})</p>`;
    }
}

function initPlayerUI() {
    const playBtn = document.getElementById('play-btn');
    const volumeSlider = document.getElementById('volume-slider');
    const lyricsBtn = document.getElementById('lyrics-btn');

    playBtn?.addEventListener('click', () => {
        // 簡易実装
        const ytStatus = YouTubeHandler.player?.getPlayerState();
        if (ytStatus === 1) YouTubeHandler.pause(); else YouTubeHandler.resume();
    });

    volumeSlider?.addEventListener('input', (e) => YouTubeHandler.setVolume(e.target.value));
    lyricsBtn?.addEventListener('click', () => document.getElementById('lyrics-panel').classList.toggle('open'));

    window.addEventListener('ytPlayerStateChange', (e) => {
        if (playBtn) playBtn.innerText = (e.detail === 1) ? '⏸️' : '▶️';
    });
}

// ログイン関数
window.loginYouTube = () => YouTubeHandler.login(AppConfig.googleClientId);
window.loginApple = () => AppleMusicHandler.login();
