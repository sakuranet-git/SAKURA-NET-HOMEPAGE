/**
 * SAKURA MUSIC - GAS Master Script (v2.7.0 POST-ONLY MODE)
 * - 全てのリクエストを POST (doPost) で処理し、GET の制限を回避
 * - 自動フォルダ検索 (SAKURA_MUSIC) 継続
 * - Base64 安定ストリーミング方式
 */

const DEFAULT_FOLDER_ID = '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS';
const FOLDER_NAME = 'SAKURA_MUSIC';

// 全て doPost へ転送
function doGet(e) {
    return createResponse({ success: false, message: 'Please use POST for all requests.' });
}

function doPost(e) {
    try {
        if (!e.postData || !e.postData.contents) {
            return createResponse({ success: false, message: 'No post data received.' });
        }
        const p = JSON.parse(e.postData.contents);
        const action = p.action || 'listFiles';

        // フォルダの取得ロジック
        function getTargetFolder(id) {
            if (id && id !== DEFAULT_FOLDER_ID) {
                try { return DriveApp.getFolderById(id); } catch (err) { }
            }
            const folders = DriveApp.getFoldersByName(FOLDER_NAME);
            if (folders.hasNext()) return folders.next();
            try { return DriveApp.getFolderById(DEFAULT_FOLDER_ID); } catch (err) { }
            return null;
        }

        const folder = getTargetFolder(p.folderId);
        if (!folder && action !== 'test') {
            return createResponse({ success: false, message: 'Folder not found. Please create SAKURA_MUSIC folder.' });
        }

        // 1. ストリーム取得 (Base64)
        if (action === 'getStream') {
            const file = DriveApp.getFileById(p.fileId);
            return createResponse({
                success: true,
                data: Utilities.base64Encode(file.getBlob().getBytes()),
                mimeType: file.getMimeType()
            });
        }

        // 2. ファイル一覧 (再帰検索)
        if (action === 'listFiles') {
            const resultFiles = [];
            function scan(fld, currentPath) {
                const it = fld.getFiles();
                while (it.hasNext()) {
                    const f = it.next();
                    const n = f.getName().toLowerCase();
                    if (n.endsWith('.mp3') || n.endsWith('.m4a') || n.endsWith('.wav') || n.endsWith('.flac')) {
                        resultFiles.push({
                            id: f.getId(),
                            name: f.getName(),
                            mimeType: f.getMimeType(),
                            path: currentPath
                        });
                    }
                }
                const sit = fld.getFolders();
                while (sit.hasNext()) {
                    const sf = sit.next();
                    scan(sf, currentPath ? currentPath + '/' + sf.getName() : sf.getName());
                }
            }
            scan(folder, "");
            return createResponse({
                success: true,
                files: resultFiles,
                folderName: folder.getName(),
                count: resultFiles.length
            });
        }

        // 3. アップロード & 削除 (以前と同様)
        if (action === 'uploadFile') {
            const file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(p.fileData.split(',')[1] || p.fileData), p.mimeType, p.fileName));
            return createResponse({ success: true, fileId: file.getId() });
        }
        if (action === 'deleteFile') {
            DriveApp.getFileById(p.fileId).setTrashed(true);
            return createResponse({ success: true });
        }

        return createResponse({ success: false, message: 'Unknown action: ' + action });
    } catch (err) {
        return createResponse({ success: false, message: err.toString() });
    }
}

function createResponse(data) {
    return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
