/**
 * SAKURA MUSIC - App Main (v1.2.8)
 * - Safe Drive Playlist Reordering (LocalStorage)
 * - Advanced Meta Extraction & Lyrics Fetching
 */

const AppConfig = {
    appleToken: localStorage.getItem('sakura_apple_token') || '',
    googleClientId: localStorage.getItem('sakura_google_id') || '1034545304058-8414nlkdpms40gjknm47r9v3efbbjdas.apps.googleusercontent.com',
    googleApiKey: localStorage.getItem('sakura_google_api_key') || 'AIzaSyD-IoqRej9KOCWDYy8W7InW3qpu6xxbW8Y',
    gasUrl: localStorage.getItem('sakura_gas_url') || 'https://script.google.com/macros/s/AKfycbyLc7Q25g8GOlwAhl2hkJSreQqfQllKsFQ7eJ1vL_ARUAG6Gz6EpnCpVygGSBiWUx1D/exec',
    driveFolderId: localStorage.getItem('sakura_drive_folder_id') || '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS',

    save(apple, google, googleApi, gasUrl, folderId) {
        localStorage.setItem('sakura_apple_token', apple || '');
        localStorage.setItem('sakura_google_id', google || '');
        localStorage.setItem('sakura_google_api_key', googleApi || '');
        localStorage.setItem('sakura_gas_url', gasUrl || '');
        localStorage.setItem('sakura_drive_folder_id', folderId || '');
    }
};

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initSettings();
    initPlayerUI();
    initSearch();
    initMobileMenu();
    YouTubeHandler.init();
    // ページ起動時に Drive キャッシュをバックグラウンドで自動開始
    startBackgroundCache();
});

// 再生状態管理用
let _cacheJobRunning = false;
window.__activePlayer = null; // 'youtube' or 'drive'

/**
 * アプリ起動時に自動的にキャッシュを開始する。
 * Drive タブを開かなくてもバックグラウンドで ⚡ マークが点灯する。
 */
async function startBackgroundCache() {
    if (_cacheJobRunning) return;
    _cacheJobRunning = true;
    try {
        const files = await DriveHandler.listFiles();
        if (!files || files.length === 0) return;

        const targets = files.slice(0, 10);
        // 未キャッシュのものだけ抽出
        const needCache = [];
        for (const f of targets) {
            if (!(await DriveHandler.isCached(f.id))) needCache.push(f);
        }

        // 2件ずつ並列でキャッシュ
        for (let i = 0; i < needCache.length; i += 2) {
            const batch = needCache.slice(i, i + 2);
            await Promise.all(batch.map(async (f) => {
                const ok = await DriveHandler.cacheAudio(f.id, f.mimeType);
                if (ok) {
                    console.log('⚡ バックグラウンドキャッシュ完了:', f.name);
                    // Drive ビューが表示中なら即座に ⚡ を点灯
                    const badge = document.querySelector(`[data-file-id="${f.id}"] .cache-badge`);
                    if (badge) badge.style.opacity = '1';
                }
            }));
        }
    } catch (err) {
        console.warn('バックグラウンドキャッシュエラー:', err);
    } finally {
        _cacheJobRunning = false;
    }
}


function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            const t = link.innerText.trim();
            if (t.includes('ホーム')) showHome();
            else if (t.includes('YouTube Music')) showYouTubeLibrary();
            else if (t.includes('Google Drive')) showDriveLibrary();
        });
    });
}

function initSettings() {
    document.getElementById('settings-btn')?.addEventListener('click', () => {
        document.getElementById('apple-token-input').value = AppConfig.appleToken;
        document.getElementById('google-id-input').value = AppConfig.googleClientId;
        document.getElementById('google-api-key-input').value = AppConfig.googleApiKey;
        document.getElementById('gas-url-input').value = AppConfig.gasUrl;
        document.getElementById('drive-folder-id-input').value = AppConfig.driveFolderId;
        document.getElementById('settings-modal').classList.add('open');
    });
    document.getElementById('save-settings')?.addEventListener('click', () => {
        AppConfig.save(
            document.getElementById('apple-token-input').value,
            document.getElementById('google-id-input').value,
            document.getElementById('google-api-key-input').value,
            document.getElementById('gas-url-input').value,
            document.getElementById('drive-folder-id-input').value
        );
        document.getElementById('settings-modal').classList.remove('open');
        location.reload();
    });
}

function initSearch() {
    const inputs = [document.getElementById('global-search'), document.getElementById('center-search')];
    inputs.forEach(input => {
        input?.addEventListener('keypress', async (e) => {
            if (e.key === 'Enter') {
                const query = input.value.trim();
                if (!query) return;
                hideAllViews();
                document.getElementById('search-view').style.display = 'block';
                const grid = document.getElementById('search-results');
                grid.innerHTML = '<p style="grid-column:1/-1; text-align:center; padding:50px;">検索中...</p>';
                try {
                    const results = await YouTubeHandler.search(query, AppConfig.googleApiKey);
                    renderSearchResults(results);
                } catch (err) {
                    grid.innerHTML = `<p style="grid-column:1/-1; text-align:center;">エラー: ${err.message}</p>`;
                }
            }
        });
    });
}

function hideAllViews() {
    ['welcome-view', 'library-view', 'playlist-detail-view', 'drive-view', 'search-view'].forEach(id => {
        const el = document.getElementById(id); if (el) el.style.display = 'none';
    });
}

function showHome() { hideAllViews(); document.getElementById('welcome-view').style.display = 'block'; }

async function showYouTubeLibrary() {
    hideAllViews();
    document.getElementById('library-view').style.display = 'block';
    const grid = document.getElementById('library-content');
    grid.innerHTML = '<p style="text-align:center; opacity:0.5;">読込中...</p>';
    const playlists = await YouTubeHandler.getLibrary();
    renderLibrary(playlists);
}

function renderLibrary(playlists) {
    const grid = document.getElementById('library-content');
    grid.innerHTML = '';
    playlists.forEach(pl => {
        const card = document.createElement('div');
        card.className = 'result-card';
        card.innerHTML = `<img src="${pl.snippet.thumbnails.medium.url}" class="result-thumb"><div class="result-title">${pl.snippet.title}</div><div style="font-size:11px; opacity:0.5;">${pl.contentDetails?.itemCount || 0} tracks</div>`;
        card.addEventListener('click', () => showPlaylistDetails(pl.id, pl.snippet.title));
        grid.appendChild(card);
    });
}

async function showPlaylistDetails(id, title) {
    hideAllViews();
    document.getElementById('playlist-detail-view').style.display = 'block';
    document.getElementById('playlist-title').innerText = title;
    const grid = document.getElementById('playlist-items');
    grid.innerHTML = '読み込み中...';
    const items = await YouTubeHandler.getPlaylistItems(id);
    grid.innerHTML = '';
    items.forEach(item => {
        const { videoId } = item.snippet.resourceId;
        const t = item.snippet.title;
        let artist = item.snippet.videoOwnerChannelTitle || 'YouTube Music';
        // v1.2.4: アーティスト名のクレンジング
        artist = artist.replace(/ - Topic$/i, '').replace(/ OFFICIAL$| Official Channel$/i, '').trim();
        const thumb = item.snippet.thumbnails?.default?.url || '';
        const row = document.createElement('div');
        row.className = 'playlist-row';
        row.style = 'display:flex; align-items:center; padding:12px; background:rgba(255,255,255,0.03); margin-bottom:8px; cursor:pointer; border-radius:12px;';
        row.innerHTML = `
            <img src="${thumb}" style="width:40px; height:40px; border-radius:6px; margin-right:15px; object-fit:cover;">
            <div style="flex:1;"><div style="font-weight:600;">${t}</div><div style="font-size:11px; opacity:0.4;">${artist}</div></div>
            <div style="font-size:16px; color:var(--primary);">▶️</div>
        `;
        row.addEventListener('click', () => playTrack(videoId, t, artist, thumb, false));
        grid.appendChild(row);
    });
}

function renderSearchResults(items) {
    const grid = document.getElementById('search-results');
    grid.innerHTML = '';
    items.forEach(item => {
        const videoId = item.id.videoId;
        const { title, thumbnails, channelTitle } = item.snippet;
        const artist = channelTitle.replace(/ - Topic$/i, '').trim();
        const card = document.createElement('div');
        card.className = 'result-card';
        card.innerHTML = `<img src="${thumbnails.medium.url}" class="result-thumb"><div class="result-title">${title}</div><div class="result-artist">${artist}</div>`;
        card.addEventListener('click', () => playTrack(videoId, title, artist, thumbnails.medium.url, false));
        grid.appendChild(card);
    });
}

async function showDriveLibrary() {
    hideAllViews();
    document.getElementById('drive-view').style.display = 'block';
    const grid = document.getElementById('drive-content');
    grid.innerHTML = '<p style="text-align:center; padding:40px; opacity:0.5;">✨ ドライブを同期中...</p>';
    const lamp = document.getElementById('drive-status-lamp');
    if (lamp) { lamp.className = ''; lamp.style.background = '#666'; }

    const files = await DriveHandler.listFiles();

    if (lamp) {
        if (files === null) { lamp.classList.add('lamp-error'); lamp.title = '接続エラー'; }
        else { lamp.classList.add('lamp-ok'); lamp.title = `接続完了 (${files.length}曲)`; }
    }

    // キャッシュチェックなしで即座に描画
    renderDriveFiles(files || []);
    setupDriveActions();

    if (!files || files.length === 0) return;

    // ⚡マーカーを並列チェックして更新（描画をブロックしない）
    Promise.all(files.map(async (f) => {
        const cached = await DriveHandler.isCached(f.id);
        if (cached) {
            const badge = document.querySelector(`[data-file-id="${f.id}"] .cache-badge`);
            if (badge) badge.style.opacity = '1';
        }
    }));

    // バックグラウンドでキャッシュ（最初の10曲、並列2件ずつ）
    const uncached = [];
    for (const f of files.slice(0, 10)) {
        if (!(await DriveHandler.isCached(f.id))) uncached.push(f);
    }
    // 2件ずつ並列でキャッシュ（サーバー負荷を抑えつつ高速化）
    for (let i = 0; i < uncached.length; i += 2) {
        const batch = uncached.slice(i, i + 2);
        await Promise.all(batch.map(async (f) => {
            const ok = await DriveHandler.cacheAudio(f.id, f.mimeType);
            if (ok) {
                const badge = document.querySelector(`[data-file-id="${f.id}"] .cache-badge`);
                if (badge) {
                    badge.style.opacity = '1';
                    console.log('⚡ キャッシュ完了:', f.name);
                }
            }
        }));
    }
}

// v1.2.8: 安全な曲順保存ロジック (LocalStorage)
function getOrderedDriveFiles(files) {
    if (!files || files.length === 0) return files;

    // LocalStorageから順序配列を取得
    let savedOrder = [];
    try {
        const stored = localStorage.getItem('sakura_drive_order');
        if (stored) savedOrder = JSON.parse(stored);
    } catch (e) { console.error('Error reading drive order', e); }

    const fileMap = new Map();
    files.forEach(f => fileMap.set(f.id, f));

    const orderedFiles = [];
    // 存在するファイルだけを保存された順序で追加
    for (const id of savedOrder) {
        if (fileMap.has(id)) {
            orderedFiles.push(fileMap.get(id));
            fileMap.delete(id);
        }
    }
    // 保存されていなかった新規ファイルは末尾に追加
    for (const [id, f] of fileMap.entries()) {
        orderedFiles.push(f);
    }

    // 最新の順序を再保存して自己修復 (描画ブロックを防ぐため非同期で)
    setTimeout(() => {
        try {
            localStorage.setItem('sakura_drive_order', JSON.stringify(orderedFiles.map(f => f.id)));
        } catch (e) { console.error('Error saving drive order', e); }
    }, 0);

    return orderedFiles;
}

// v1.2.8: 曲順移動アクション
window.moveDriveFile = function (fileId, direction) {
    if (!DriveHandler._cache) return;
    const files = getOrderedDriveFiles(DriveHandler._cache);
    const index = files.findIndex(f => f.id === fileId);

    if (index === -1) return;
    if (direction === 'up' && index > 0) {
        [files[index], files[index - 1]] = [files[index - 1], files[index]];
    } else if (direction === 'down' && index < files.length - 1) {
        [files[index], files[index + 1]] = [files[index + 1], files[index]];
    } else {
        return;
    }

    // 並び替えた順序を保存
    try {
        localStorage.setItem('sakura_drive_order', JSON.stringify(files.map(f => f.id)));
    } catch (e) { console.error('Error saving new drive order', e); }

    // 画面を再描画（瞬時に反映）
    renderDriveFiles(DriveHandler._cache);
};

function renderDriveFiles(rawFiles) {
    const content = document.getElementById('drive-content');
    if (!rawFiles || rawFiles.length === 0) {
        content.innerHTML = `<div style="text-align:center; padding:40px; opacity:0.6;"><p>楽曲が見つかりませんでした。</p></div>`;
        return;
    }

    // 取得したファイルをユーザーのカスタム順序に並び替え
    const files = getOrderedDriveFiles(rawFiles);
    content.innerHTML = '';

    for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const isFirst = (i === 0);
        const isLast = (i === files.length - 1);

        const item = document.createElement('div');
        item.className = 'drive-list-item';
        item.dataset.fileId = f.id;
        item.innerHTML = `
            <div style="display:flex; align-items:center; flex:1;">
                <div style="width:32px; height:32px; background:rgba(230,0,126,0.1); border-radius:6px; display:flex; align-items:center; justify-content:center; margin-right:12px;">🎵</div>
                <div style="min-width:0; flex:1;">
                    <div style="font-weight:bold; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${f.name}</div>
                    <div style="font-size:10px; opacity:0.4;">${f.path || 'Root'}</div>
                </div>
            </div>
            
            <div class="move-controls" style="display:flex; flex-direction:column; margin-right:8px; align-items:center; justify-content:center;">
                <button class="move-up-btn" style="background:none; border:none; padding:2px; font-size:16px; cursor:${isFirst ? 'default' : 'pointer'}; opacity:${isFirst ? 0.1 : 0.6}; transition:opacity 0.2s; color:#333;">▲</button>
                <button class="move-down-btn" style="background:none; border:none; padding:2px; font-size:16px; cursor:${isLast ? 'default' : 'pointer'}; opacity:${isLast ? 0.1 : 0.6}; transition:opacity 0.2s; color:#333;">▼</button>
            </div>

            <span class="cache-badge" title="キャッシュ済みで高速再生" style="font-size:14px; margin-right:8px; opacity:0.15; transition:opacity 0.5s;">⚡</span>
            <button class="delete-btn" style="background:none; border:none; color:#ff4d4d; cursor:pointer; padding:8px;">✕</button>
        `;

        // トラッククリック再生イベント（ボタン以外）
        item.addEventListener('click', (e) => {
            if (!e.target.closest('button')) playTrack(f.id, f.name, 'Google Drive', '', true);
        });

        // 移動ボタンイベント
        const upBtn = item.querySelector('.move-up-btn');
        const downBtn = item.querySelector('.move-down-btn');

        if (!isFirst) {
            upBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                moveDriveFile(f.id, 'up');
            });
            upBtn.addEventListener('mouseenter', () => upBtn.style.opacity = '1');
            upBtn.addEventListener('mouseleave', () => upBtn.style.opacity = '0.6');
        }

        if (!isLast) {
            downBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                moveDriveFile(f.id, 'down');
            });
            downBtn.addEventListener('mouseenter', () => downBtn.style.opacity = '1');
            downBtn.addEventListener('mouseleave', () => downBtn.style.opacity = '0.6');
        }

        // 削除ボタンイベント
        item.querySelector('.delete-btn').addEventListener('click', async (e) => {
            e.stopPropagation();
            if (confirm(`「${f.name}」を削除しますか？`)) { await DriveHandler.deleteFile(f.id); showDriveLibrary(); }
        });

        content.appendChild(item);
    }
}

function setupDriveActions() {
    const trigger = document.getElementById('drive-upload-trigger');
    const input = document.getElementById('drive-upload-input');
    if (!trigger || trigger.dataset.init) return;
    trigger.dataset.init = "true";
    trigger.addEventListener('click', () => input.click());
    input.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        const container = document.getElementById('upload-progress-container');
        if (container) container.style.display = 'block';
        for (const file of files) {
            document.getElementById('upload-filename').innerText = file.name;
            await DriveHandler.uploadFile(file);
        }
        if (container) container.style.display = 'none';
        showDriveLibrary();
    });
}

async function playTrack(id, title, artist, thumb, isDrive = false) {
    if (window.__localAudio) window.__localAudio.pause();
    YouTubeHandler.pause();

    // 表示用のクレンジング (v1.2.2)
    let displayTitle = title;
    let displayArtist = artist;
    if (isDrive) {
        // 簡易クレンジング
        displayTitle = title.replace(/\.(mp3|m4a|wav|flac)$/i, '').replace(/^\d+[\s._-]+/, '').trim();
        if (title.includes(' - ')) {
            const parts = title.split(' - ');
            displayArtist = parts[0].replace(/^\d+[\s._-]+/, '').trim();
            displayTitle = parts[1].replace(/\.(mp3|m4a|wav|flac)$/i, '').trim();
        }
    }

    document.querySelector('.track-details h3').innerText = displayTitle;
    document.querySelector('.track-details p').innerText = displayArtist;
    if (thumb) {
        document.querySelector('.album-art').style.backgroundImage = `url(${thumb})`;
        document.querySelector('.album-art').style.backgroundSize = 'cover';
    }
    const playBtn = document.querySelector('.play-btn');
    if (playBtn) playBtn.innerText = '⏳';
    if (isDrive) {
        // キャッシュがあれば即再生（IDB 優先）、なければ GAS から取得
        let blobUrl = await DriveHandler.getCachedBlobUrl(id);
        if (blobUrl) {
            console.log('⚡ キャッシュから再生:', title);
        } else {
            blobUrl = await DriveHandler.fetchAudioStream(id);
            // 取得したついでにキャッシュに保存
            if (blobUrl) DriveHandler.cacheAudio(id, 'audio/mpeg');
        }
        if (blobUrl) {
            window.__localAudio = new Audio(blobUrl);
            window.__localAudio.play();
            window.__activePlayer = 'drive';
            if (playBtn) playBtn.innerText = '⏸️';
            // 再生終了時の処理
            window.__localAudio.onended = () => { if (playBtn) playBtn.innerText = '▶️'; };
        } else {
            alert('Drive 再生失敗'); if (playBtn) playBtn.innerText = '▶️';
        }
    } else {
        YouTubeHandler.play(id);
        if (playBtn) playBtn.innerText = '⏸️';
        window.__activePlayer = 'youtube';
    }
    fetchLyrics(title, artist);
}

/**
 * 再生・一時停止の統合制御
 */
function togglePlayback() {
    const playBtn = document.querySelector('.play-btn');
    if (window.__activePlayer === 'drive' && window.__localAudio) {
        if (window.__localAudio.paused) {
            window.__localAudio.play();
            if (playBtn) playBtn.innerText = '⏸️';
        } else {
            window.__localAudio.pause();
            if (playBtn) playBtn.innerText = '▶️';
        }
    } else if (window.__activePlayer === 'youtube') {
        const state = YouTubeHandler.player?.getPlayerState();
        if (state === 1) { // playing
            YouTubeHandler.pause();
            if (playBtn) playBtn.innerText = '▶️';
        } else {
            YouTubeHandler.resume();
            if (playBtn) playBtn.innerText = '⏸️';
        }
    }
}


async function fetchLyrics(title, artist) {
    const pane = document.getElementById('lyrics-content');
    document.getElementById('lyrics-track-title').innerText = title;
    document.getElementById('lyrics-track-artist').innerText = artist;
    pane.innerHTML = '<p style="opacity:0.3;">歌詞を捜索中...</p>';

    // 高度なクレンジング処理 (v1.2.2)
    let cT = title;
    let cA = artist;

    // 共通の不要語削除 (v1.2.6 ライブ音源・カバー曲対応版)
    const cleanStr = (s) => s.replace(/\.(mp3|m4a|wav|flac)$/i, '')
        .replace(/^\d+[\s._-]+/, '') // トラック番号 01. 01 - 等
        .replace(/いつもの|～.*?～|〈.*?〉|\[.*?\]|\(.*?\)/g, (m) => {
            // ライブ関連キーワードや不要語が含まれていれば削除、そうでなければ残す
            return /official|video|audio|lyric|full|mv|topic|only|live|tour|day\.\d+|lovelive|いつもの/i.test(m) ? '' : m;
        })
        .replace(/Official Video|Music Video|Lyric Video|Full Audio|MV|Audio Only|Official Audio|Audio/gi, '')
        .replace(/ - Topic$| OFFICIAL$| Official Channel$/i, '')
        .replace(/Live ver\.?|Live Version/gi, '')
        .replace(/\s+/g, ' ')
        .trim();

    const isGenericArtist = (a) => {
        const lower = a.toLowerCase();
        return lower.includes('google drive') || lower === 'youtube music' || lower === 'youtube' || lower === 'unknown' || lower === 'music' || lower === '' || lower === 'various artists';
    };

    if (isGenericArtist(cA)) {
        // タイトル自体にアーティスト情報が含まれている場合が多い
        if (title.includes(' - ')) {
            const parts = title.split(' - ');
            cA = parts[0];
            cT = parts[1];
        } else if (title.includes('「') && title.includes('」')) {
            const match = title.match(/(.*?)「(.*?)」/);
            if (match) { cA = match[1]; cT = match[2]; }
        } else if (title.includes('/')) {
            const parts = title.split('/');
            cA = parts[0];
            cT = parts[1];
        } else {
            cA = '';
        }
    }

    cT = cleanStr(cT);
    cA = (cA && !isGenericArtist(cA)) ? cleanStr(cA) : '';

    const tryDisplay = (data, force = false) => {
        if (!data) return false;
        // v1.2.6: アーティスト名の検証 (カバー曲・ライブ盤での不一致を許容しつつ、全く無関係な曲を弾く)
        if (cA && !force) {
            const dataArtist = data.artistName.toLowerCase();
            const currentArtist = cA.toLowerCase();
            const dataTrack = data.trackName.toLowerCase();
            const currentTrack = cT.toLowerCase();

            // アーティストが一致するか、またはタイトルが非常に強く一致している場合は許可
            const isArtistMatch = dataArtist.includes(currentArtist) || currentArtist.includes(dataArtist);
            const isTrackMatch = dataTrack === currentTrack || dataTrack.includes(currentTrack) || currentTrack.includes(dataTrack);

            if (!isArtistMatch && !isTrackMatch) {
                console.warn(`Mismatch: Found "${data.artistName} - ${data.trackName}" for "${cA} - ${cT}"`);
                return false;
            }
        }
        document.getElementById('lyrics-track-title').innerText = data.trackName;
        document.getElementById('lyrics-track-artist').innerText = data.artistName;
        document.querySelector('.track-details h3').innerText = data.trackName;
        document.querySelector('.track-details p').innerText = data.artistName;
        pane.innerText = data.plainLyrics || data.syncedLyrics?.replace(/\[\d+:\d+\.\d+\]/g, '') || '歌詞がありません';
        return true;
    };

    try {
        // 1. 普通に GET 試行
        const res = await fetch(`https://lrclib.net/api/get?artist_name=${encodeURIComponent(cA)}&track_name=${encodeURIComponent(cT)}`);
        if (res.ok) {
            const data = await res.json();
            if (tryDisplay(data)) return;
        }

        // 2. 検索 API でリトライ
        const sRes = await fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(cT + " " + cA)}`);
        const sData = await sRes.json();
        if (sData && sData.length > 0) {
            if (tryDisplay(sData[0])) return;
        }

        // 3. (v1.2.5) 英数字キーワード抽出リトライ
        const alphaKeywords = cT.replace(/[^\x20-\x7E]/g, ' ').split(/\s+/).filter(w => w.length > 2).join(' ');
        if (alphaKeywords) {
            const sRes2 = await fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(cA + " " + alphaKeywords)}`);
            const sData2 = await sRes2.json();
            if (sData2 && sData2.length > 0) {
                if (tryDisplay(sData2[0])) return;
            }
        }

        // 4. (v1.2.6 最終手段) アーティストを無視してタイトルのみで検索 (カバー曲対応)
        const sRes3 = await fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(cT)}`);
        const sData3 = await sRes3.json();
        if (sData3 && sData3.length > 0) {
            // タイトルの完全一致を優先的に探す
            const bestMatch = sData3.find(d => d.trackName.toLowerCase() === cT.toLowerCase());
            if (tryDisplay(bestMatch || sData3[0])) return;
        }

        // 5. (v1.2.7 追加バックアップ) lyrics.ovh API を用いたフォールバック検索
        if (cA) {
            try {
                console.log("lrclib.net failed. Trying lyrics.ovh as fallback...");
                const ovhRes = await fetch(`https://api.lyrics.ovh/v1/${encodeURIComponent(cA)}/${encodeURIComponent(cT)}`);
                if (ovhRes.ok) {
                    const ovhData = await ovhRes.json();
                    if (ovhData && ovhData.lyrics) {
                        document.getElementById('lyrics-track-title').innerText = cT;
                        document.getElementById('lyrics-track-artist').innerText = cA;
                        document.querySelector('.track-details h3').innerText = cT;
                        document.querySelector('.track-details p').innerText = cA;
                        // lyrics.ovhはプレーンテキストのみ提供
                        pane.innerText = ovhData.lyrics;
                        return; // 成功したら終了
                    }
                }
            } catch (ovhError) {
                console.warn('lyrics.ovh Fetch Error:', ovhError);
            }
        }

        pane.innerHTML = '<p style="opacity:0.5;">歌詞が見つかりませんでした。</p>';
    } catch (e) {
        console.error('Lyrics Fetch Error:', e);
        pane.innerHTML = '<p style="opacity:0.5;">歌詞の取得に失敗しました。</p>';
    }
}

function initPlayerUI() {
    const btn = document.getElementById('play-btn');
    btn?.addEventListener('click', togglePlayback);
    document.getElementById('volume-slider')?.addEventListener('input', (e) => YouTubeHandler.setVolume(e.target.value));
    document.getElementById('lyrics-btn')?.addEventListener('click', () => document.getElementById('lyrics-panel').classList.toggle('open'));
    window.addEventListener('ytPlayerStateChange', (e) => { if (btn) btn.innerText = (e.detail === 1) ? '⏸️' : '▶️'; });
}

function initMobileMenu() {
    const toggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar-nav');
    const overlay = document.getElementById('sidebar-overlay');
    const navLinks = document.querySelectorAll('.nav-link');

    if (!toggle || !sidebar || !overlay) return;

    const closeMenu = () => {
        sidebar.classList.remove('open');
        overlay.style.display = 'none';
        document.body.style.position = ''; // スクロールロック解除
    };

    toggle.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = sidebar.classList.contains('open');
        if (isOpen) {
            closeMenu();
        } else {
            sidebar.classList.add('open');
            overlay.style.display = 'block';
            document.body.style.position = 'fixed'; // 背面のスクロールを防止
        }
    });

    overlay.addEventListener('click', closeMenu);

    navLinks.forEach(link => {
        link.addEventListener('click', closeMenu);
    });
}

window.loginYouTube = () => YouTubeHandler.login(AppConfig.googleClientId);
window.loginApple = () => AppleMusicHandler.login();
