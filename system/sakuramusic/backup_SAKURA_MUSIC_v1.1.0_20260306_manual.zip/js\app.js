/**
 * SAKURA MUSIC - App Main (v1.0.66)
 * - IndexedDB Audio Cache（⚡ マーカー）
 * - 正しい GAS URL (ai.sakuranet@gmail.com)
 * - YouTube Search & Drive Library
 */

const AppConfig = {
    appleToken: localStorage.getItem('sakura_apple_token') || '',
    googleClientId: localStorage.getItem('sakura_google_id') || '1034545304058-8414nlkdpms40gjknm47r9v3efbbjdas.apps.googleusercontent.com',
    googleApiKey: localStorage.getItem('sakura_google_api_key') || 'AIzaSyD-IoqRej9KOCWDYy8W7InW3qpu6xxbW8Y',
    gasUrl: localStorage.getItem('sakura_gas_url') || 'https://script.google.com/macros/s/AKfycbyLc7Q25g8GOlwAhl2hkJSreQqfQllKsFQ7eJ1vL_ARUAG6Gz6EpnCpVygGSBiWUx1D/exec',
    driveFolderId: localStorage.getItem('sakura_drive_folder_id') || '1ftI36zOUQ_snJEFTBqPbRbbxH18cLckS',

    save(apple, google, googleApi, gasUrl, folderId) {
        localStorage.setItem('sakura_apple_token', apple || '');
        localStorage.setItem('sakura_google_id', google || '');
        localStorage.setItem('sakura_google_api_key', googleApi || '');
        localStorage.setItem('sakura_gas_url', gasUrl || '');
        localStorage.setItem('sakura_drive_folder_id', folderId || '');
    }
};

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initSettings();
    initPlayerUI();
    initSearch();
    YouTubeHandler.init();
    // ページ起動時に Drive キャッシュをバックグラウンドで自動開始
    startBackgroundCache();
});

// 二重実行防止フラグ
let _cacheJobRunning = false;

/**
 * アプリ起動時に自動的にキャッシュを開始する。
 * Drive タブを開かなくてもバックグラウンドで ⚡ マークが点灯する。
 */
async function startBackgroundCache() {
    if (_cacheJobRunning) return;
    _cacheJobRunning = true;
    try {
        const files = await DriveHandler.listFiles();
        if (!files || files.length === 0) return;

        const targets = files.slice(0, 10);
        // 未キャッシュのものだけ抽出
        const needCache = [];
        for (const f of targets) {
            if (!(await DriveHandler.isCached(f.id))) needCache.push(f);
        }

        // 2件ずつ並列でキャッシュ
        for (let i = 0; i < needCache.length; i += 2) {
            const batch = needCache.slice(i, i + 2);
            await Promise.all(batch.map(async (f) => {
                const ok = await DriveHandler.cacheAudio(f.id, f.mimeType);
                if (ok) {
                    console.log('⚡ バックグラウンドキャッシュ完了:', f.name);
                    // Drive ビューが表示中なら即座に ⚡ を点灯
                    const badge = document.querySelector(`[data-file-id="${f.id}"] .cache-badge`);
                    if (badge) badge.style.opacity = '1';
                }
            }));
        }
    } catch (err) {
        console.warn('バックグラウンドキャッシュエラー:', err);
    } finally {
        _cacheJobRunning = false;
    }
}


function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            const t = link.innerText.trim();
            if (t.includes('ホーム')) showHome();
            else if (t.includes('YouTube Music')) showYouTubeLibrary();
            else if (t.includes('Google Drive')) showDriveLibrary();
        });
    });
}

function initSettings() {
    document.getElementById('settings-btn')?.addEventListener('click', () => {
        document.getElementById('apple-token-input').value = AppConfig.appleToken;
        document.getElementById('google-id-input').value = AppConfig.googleClientId;
        document.getElementById('google-api-key-input').value = AppConfig.googleApiKey;
        document.getElementById('gas-url-input').value = AppConfig.gasUrl;
        document.getElementById('drive-folder-id-input').value = AppConfig.driveFolderId;
        document.getElementById('settings-modal').classList.add('open');
    });
    document.getElementById('save-settings')?.addEventListener('click', () => {
        AppConfig.save(
            document.getElementById('apple-token-input').value,
            document.getElementById('google-id-input').value,
            document.getElementById('google-api-key-input').value,
            document.getElementById('gas-url-input').value,
            document.getElementById('drive-folder-id-input').value
        );
        document.getElementById('settings-modal').classList.remove('open');
        location.reload();
    });
}

function initSearch() {
    const inputs = [document.getElementById('global-search'), document.getElementById('center-search')];
    inputs.forEach(input => {
        input?.addEventListener('keypress', async (e) => {
            if (e.key === 'Enter') {
                const query = input.value.trim();
                if (!query) return;
                hideAllViews();
                document.getElementById('search-view').style.display = 'block';
                const grid = document.getElementById('search-results');
                grid.innerHTML = '<p style="grid-column:1/-1; text-align:center; padding:50px;">検索中...</p>';
                try {
                    const results = await YouTubeHandler.search(query, AppConfig.googleApiKey);
                    renderSearchResults(results);
                } catch (err) {
                    grid.innerHTML = `<p style="grid-column:1/-1; text-align:center;">エラー: ${err.message}</p>`;
                }
            }
        });
    });
}

function hideAllViews() {
    ['welcome-view', 'library-view', 'playlist-detail-view', 'drive-view', 'search-view'].forEach(id => {
        const el = document.getElementById(id); if (el) el.style.display = 'none';
    });
}

function showHome() { hideAllViews(); document.getElementById('welcome-view').style.display = 'block'; }

async function showYouTubeLibrary() {
    hideAllViews();
    document.getElementById('library-view').style.display = 'block';
    const grid = document.getElementById('library-content');
    grid.innerHTML = '<p style="text-align:center; opacity:0.5;">読込中...</p>';
    const playlists = await YouTubeHandler.getLibrary();
    renderLibrary(playlists);
}

function renderLibrary(playlists) {
    const grid = document.getElementById('library-content');
    grid.innerHTML = '';
    playlists.forEach(pl => {
        const card = document.createElement('div');
        card.className = 'result-card';
        card.innerHTML = `<img src="${pl.snippet.thumbnails.medium.url}" class="result-thumb"><div class="result-title">${pl.snippet.title}</div><div style="font-size:11px; opacity:0.5;">${pl.contentDetails?.itemCount || 0} tracks</div>`;
        card.addEventListener('click', () => showPlaylistDetails(pl.id, pl.snippet.title));
        grid.appendChild(card);
    });
}

async function showPlaylistDetails(id, title) {
    hideAllViews();
    document.getElementById('playlist-detail-view').style.display = 'block';
    document.getElementById('playlist-title').innerText = title;
    const grid = document.getElementById('playlist-items');
    grid.innerHTML = '読み込み中...';
    const items = await YouTubeHandler.getPlaylistItems(id);
    grid.innerHTML = '';
    items.forEach(item => {
        const { videoId } = item.snippet.resourceId;
        const t = item.snippet.title;
        const thumb = item.snippet.thumbnails?.default?.url || '';
        const row = document.createElement('div');
        row.className = 'playlist-row';
        row.style = 'display:flex; align-items:center; padding:12px; background:rgba(255,255,255,0.03); margin-bottom:8px; cursor:pointer; border-radius:12px;';
        row.innerHTML = `
            <img src="${thumb}" style="width:40px; height:40px; border-radius:6px; margin-right:15px; object-fit:cover;">
            <div style="flex:1;"><div style="font-weight:600;">${t}</div><div style="font-size:11px; opacity:0.4;">YouTube Music</div></div>
            <div style="font-size:16px; color:var(--primary);">▶️</div>
        `;
        row.addEventListener('click', () => playTrack(videoId, t, 'YouTube Music', thumb, false));
        grid.appendChild(row);
    });
}

function renderSearchResults(items) {
    const grid = document.getElementById('search-results');
    grid.innerHTML = '';
    items.forEach(item => {
        const videoId = item.id.videoId;
        const { title, thumbnails, channelTitle } = item.snippet;
        const card = document.createElement('div');
        card.className = 'result-card';
        card.innerHTML = `<img src="${thumbnails.medium.url}" class="result-thumb"><div class="result-title">${title}</div><div class="result-artist">${channelTitle}</div>`;
        card.addEventListener('click', () => playTrack(videoId, title, channelTitle, thumbnails.medium.url, false));
        grid.appendChild(card);
    });
}

async function showDriveLibrary() {
    hideAllViews();
    document.getElementById('drive-view').style.display = 'block';
    const grid = document.getElementById('drive-content');
    grid.innerHTML = '<p style="text-align:center; padding:40px; opacity:0.5;">✨ ドライブを同期中...</p>';
    const lamp = document.getElementById('drive-status-lamp');
    if (lamp) { lamp.className = ''; lamp.style.background = '#666'; }

    const files = await DriveHandler.listFiles();

    if (lamp) {
        if (files === null) { lamp.classList.add('lamp-error'); lamp.title = '接続エラー'; }
        else { lamp.classList.add('lamp-ok'); lamp.title = `接続完了 (${files.length}曲)`; }
    }

    // キャッシュチェックなしで即座に描画
    renderDriveFiles(files || []);
    setupDriveActions();

    if (!files || files.length === 0) return;

    // ⚡マーカーを並列チェックして更新（描画をブロックしない）
    Promise.all(files.map(async (f) => {
        const cached = await DriveHandler.isCached(f.id);
        if (cached) {
            const badge = document.querySelector(`[data-file-id="${f.id}"] .cache-badge`);
            if (badge) badge.style.opacity = '1';
        }
    }));

    // バックグラウンドでキャッシュ（最初の10曲、並列2件ずつ）
    const uncached = [];
    for (const f of files.slice(0, 10)) {
        if (!(await DriveHandler.isCached(f.id))) uncached.push(f);
    }
    // 2件ずつ並列でキャッシュ（サーバー負荷を抑えつつ高速化）
    for (let i = 0; i < uncached.length; i += 2) {
        const batch = uncached.slice(i, i + 2);
        await Promise.all(batch.map(async (f) => {
            const ok = await DriveHandler.cacheAudio(f.id, f.mimeType);
            if (ok) {
                const badge = document.querySelector(`[data-file-id="${f.id}"] .cache-badge`);
                if (badge) { badge.style.opacity = '1'; console.log('⚡ キャッシュ完了:', f.name); }
            }
        }));
    }
}

function renderDriveFiles(files) {
    const content = document.getElementById('drive-content');
    if (!files || files.length === 0) {
        content.innerHTML = `<div style="text-align:center; padding:40px; opacity:0.6;"><p>楽曲が見つかりませんでした。</p></div>`;
        return;
    }
    content.innerHTML = '';
    for (const f of files) {
        const item = document.createElement('div');
        item.className = 'drive-list-item';
        item.dataset.fileId = f.id;
        item.innerHTML = `
            <div style="display:flex; align-items:center; flex:1;">
                <div style="width:32px; height:32px; background:rgba(230,0,126,0.1); border-radius:6px; display:flex; align-items:center; justify-content:center; margin-right:12px;">🎵</div>
                <div style="min-width:0; flex:1;">
                    <div style="font-weight:bold; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${f.name}</div>
                    <div style="font-size:10px; opacity:0.4;">${f.path || 'Root'}</div>
                </div>
            </div>
            <span class="cache-badge" title="キャッシュ済みで高速再生" style="font-size:14px; margin-right:8px; opacity:0.15; transition:opacity 0.5s;">⚡</span>
            <button class="delete-btn" style="background:none; border:none; color:#ff4d4d; cursor:pointer; padding:8px;">✕</button>
        `;
        item.addEventListener('click', (e) => { if (!e.target.classList.contains('delete-btn')) playTrack(f.id, f.name, 'Google Drive', '', true); });
        item.querySelector('.delete-btn').addEventListener('click', async (e) => {
            e.stopPropagation();
            if (confirm(`「${f.name}」を削除しますか？`)) { await DriveHandler.deleteFile(f.id); showDriveLibrary(); }
        });
        content.appendChild(item);
    }
}

function setupDriveActions() {
    const trigger = document.getElementById('drive-upload-trigger');
    const input = document.getElementById('drive-upload-input');
    if (!trigger || trigger.dataset.init) return;
    trigger.dataset.init = "true";
    trigger.addEventListener('click', () => input.click());
    input.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        const container = document.getElementById('upload-progress-container');
        if (container) container.style.display = 'block';
        for (const file of files) {
            document.getElementById('upload-filename').innerText = file.name;
            await DriveHandler.uploadFile(file);
        }
        if (container) container.style.display = 'none';
        showDriveLibrary();
    });
}

async function playTrack(id, title, artist, thumb, isDrive = false) {
    if (window.__localAudio) window.__localAudio.pause();
    YouTubeHandler.pause();
    document.querySelector('.track-details h3').innerText = title;
    document.querySelector('.track-details p').innerText = artist;
    if (thumb) {
        document.querySelector('.album-art').style.backgroundImage = `url(${thumb})`;
        document.querySelector('.album-art').style.backgroundSize = 'cover';
    }
    const playBtn = document.querySelector('.play-btn');
    if (playBtn) playBtn.innerText = '⏳';
    if (isDrive) {
        // キャッシュがあれば即再生（IDB 優先）、なければ GAS から取得
        let blobUrl = await DriveHandler.getCachedBlobUrl(id);
        if (blobUrl) {
            console.log('⚡ キャッシュから再生:', title);
        } else {
            console.log('📡 GAS からストリーミング:', title);
            blobUrl = await DriveHandler.fetchAudioStream(id);
            // 取得したついでにキャッシュに保存
            if (blobUrl) DriveHandler.cacheAudio(id, 'audio/mpeg');
        }
        if (blobUrl) {
            window.__localAudio = new Audio(blobUrl);
            window.__localAudio.play();
            if (playBtn) playBtn.innerText = '⏸️';
        } else {
            alert('Drive 再生失敗'); if (playBtn) playBtn.innerText = '▶️';
        }
    } else {
        YouTubeHandler.play(id); if (playBtn) playBtn.innerText = '⏸️';
    }
    fetchLyrics(title, artist);
}


async function fetchLyrics(title, artist) {
    const pane = document.getElementById('lyrics-content');
    document.getElementById('lyrics-track-title').innerText = title;
    document.getElementById('lyrics-track-artist').innerText = artist;
    pane.innerHTML = '<p style="opacity:0.3;">歌詞を捜索中...</p>';
    const cT = title.replace(/\[.*?\]|\(.*?\)|Official Video|Music Video|Lyric Video|Full Audio|MV/gi, '').trim();
    const cA = artist.replace(/ - Topic$/i, '').trim();
    try {
        const res = await fetch(`https://lrclib.net/api/get?artist_name=${encodeURIComponent(cA)}&track_name=${encodeURIComponent(cT)}`);
        const data = await res.json();
        pane.innerText = data.plainLyrics || data.syncedLyrics?.replace(/\[\d+:\d+\.\d+\]/g, '') || '歌詞がありません';
    } catch {
        pane.innerHTML = '<p style="opacity:0.5;">歌詞が見つかりませんでした。</p>';
    }
}

function initPlayerUI() {
    const btn = document.getElementById('play-btn');
    btn?.addEventListener('click', () => {
        const state = YouTubeHandler.player?.getPlayerState();
        if (state === 1) YouTubeHandler.pause(); else YouTubeHandler.resume();
    });
    document.getElementById('volume-slider')?.addEventListener('input', (e) => YouTubeHandler.setVolume(e.target.value));
    document.getElementById('lyrics-btn')?.addEventListener('click', () => document.getElementById('lyrics-panel').classList.toggle('open'));
    window.addEventListener('ytPlayerStateChange', (e) => { if (btn) btn.innerText = (e.detail === 1) ? '⏸️' : '▶️'; });
}

window.loginYouTube = () => YouTubeHandler.login(AppConfig.googleClientId);
window.loginApple = () => AppleMusicHandler.login();
