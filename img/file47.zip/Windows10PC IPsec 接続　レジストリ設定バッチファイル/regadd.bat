@echo off

powershell.exe -Command Start-Process reg -Verb Runas -WindowStyle hidden -ArgumentList 'add HKLM\SYSTEM\CurrentControlSet\Services\PolicyAgent /v AssumeUDPEncapsulationContextOnSendRule /t REG_DWORD /d 2 /f'

